def Positive(a, b):
  total = 0
  while x > 0 and b > x:
    num = input("Enter 2 numbers: ")
    if b/a and b % a == 0:
      print(total)
# can't figure out